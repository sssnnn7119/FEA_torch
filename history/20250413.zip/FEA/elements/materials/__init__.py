import torch
from .hyperelastic import NeoHookean
from .base import Materials_Base


__all__ = ['initialize_materials', 'Materials_Base', 'NeoHookean']

def initialize_materials(materials_type: int,
                         materials_params: torch.Tensor):

    if materials_type == 1:
        mu = materials_params[:, 0]
        kappa = materials_params[:, 1]
        mat_now = NeoHookean(mu, kappa)
    else:
        raise Exception('Unknown material type')
    return mat_now
