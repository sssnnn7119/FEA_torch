import torch
import numpy as np

class Surface_base():
    """
    Base class for surface elements.
    """
    def __init__(self, elems: np.ndarray,):
        
        self.shape_function: list[torch.Tensor]
        """
            the shape functions of the element

            # coordinates: (g,h,r) in the local coordinates
                0: constant,\n
                1: g,\n
                2: h,\n
                3: g*h,\n
                4: g^2,\n
                5: h^2,\n
                6: g^2*h,\n
                7: g*h^2,\n
                8: g^3,\n
                9: h^3,\n

            # the shape of shape_function 
                
                a-th func,\n
                b-th coordinates
                
            # its derivative:
                
                m-th derivative,\n
                a-th func,\n
                b-th coordinates
                
            # and its 2-nd derivative
                
                m-th derivative,\n
                n-th derivative,\n
                a-th func,\n
                b-th coordinates
        """
        
        self.shape_function_gaussian: list[torch.Tensor]
        """
            the shape functions of each guassian point
            [
                [
                    g: guassian point
                    e: element
                    a: a-th node
                ],
                [
                    g: guassian point
                    e: element
                    i: derivative
                    a: a-th node
                ]
            ]
        """

        self.gaussian_weight: torch.Tensor
        """
            the weight of each guassian point
            [
                g: guassian point
            ]
        """

        self._num_gaussian: int
        """
            the number of guassian points
        """
        
        self._elems: np.ndarray = elems
        """
            the elements of the element
            [e, n], e: the number of elements, n: the number of nodes in the element
        """
        
    def _pre_load_gaussian(self, gauss_coordinates: torch.Tensor, nodes: torch.Tensor):
        """
        load the guassian points and its weight

        Args:
            p0: [g, 2], the local coordinates of the element
        """

        pp = torch.zeros([self._num_gaussian, self.shape_function[0].shape[1]])
        pp[:, 0] = 1
        pp[:, 1] = gauss_coordinates[:, 0]
        pp[:, 2] = gauss_coordinates[:, 1]
        if self.shape_function[0].shape[1] > 3:
            pp[:, 3] = gauss_coordinates[:, 0] * gauss_coordinates[:, 1]
        if self.shape_function[0].shape[1] > 4:
            pp[:, 4] = gauss_coordinates[:, 0]**2
            pp[:, 5] = gauss_coordinates[:, 1]**2
        if self.shape_function[0].shape[1] > 6:
            pp[:, 6] = gauss_coordinates[:, 0]**2 * gauss_coordinates[:, 1]
            pp[:, 7] = gauss_coordinates[:, 1]**2 * gauss_coordinates[:, 0]
        if self.shape_function[0].shape[1] > 8:
            pp[:, 8] = gauss_coordinates[:, 0]**3
            pp[:, 9] = gauss_coordinates[:, 1]**3


        Jacobian = torch.zeros([self._num_gaussian, len(self._elems), 2, 3])
        shape_now = self.shape_function[1]
        for i in range(self._elems.shape[1]):
            Jacobian += torch.einsum('gb,mb,ei->geim', pp, shape_now[:, i],
                                     nodes[self._elems[:, i]])

        # Jacobian_Function
        # J: g(Gaussian) * e * 2(ref) * 3(rest)
        det_Jacobian = Jacobian.det()
        inv_Jacobian = Jacobian.inverse()
        shapeFun1 = torch.einsum('gemi,gb,mab->geia', inv_Jacobian, pp,
                                shape_now)
        shapeFun0 = torch.einsum('ab, gb->ga', self.shape_function[0],
                                      pp)
        
        self.shape_function_gaussian = [shapeFun0, shapeFun1]
        self.gaussian_weight = torch.einsum('ge, g->ge', det_Jacobian, self.gaussian_weight)

    def _shape_function_derivative(self, shape_function: torch.Tensor, ind: int):
        """
        get the derivative of the shape function

        Args:
            shape_function: [i, m], the shape function of the element
            ind: the index of the derivative

        Returns:
            torch.Tensor: the derivative of the shape function
        """

        # (1,g,h,g*h,g^2,h^2,g^2*h,g*h^2,g^3,h^3)
        # [0,1,2,3,  4,  5,  6,    7,    8,  9]
        
        result = torch.zeros_like(shape_function)
        
        if ind==0:
            result[:, 0] = shape_function[:, 1]
            if shape_function.shape[1] > 3:
                result[:, 2] = shape_function[:, 3]
            if shape_function.shape[1] > 4:
                result[:, 1] = shape_function[:, 4] * 2
            if shape_function.shape[1] > 6:
                result[:, 3] = shape_function[:, 6] * 2
                result[:, 5] = shape_function[:, 7]
            if shape_function.shape[1] > 8:
                result[:, 4] = shape_function[:, 8] * 3
        
        elif ind==1:
            result[:, 0] = shape_function[:, 2]
            if shape_function.shape[1] > 3:
                result[:, 1] = shape_function[:, 3]
            if shape_function.shape[1] > 4:
                result[:, 2] = shape_function[:, 5] * 2
            if shape_function.shape[1] > 6:
                result[:, 4] = shape_function[:, 6]
                result[:, 3] = shape_function[:, 7] * 2
            if shape_function.shape[1] > 8:
                result[:, 5] = shape_function[:, 9] * 3
        

        return result

class triangle_1st(Surface_base):
    """
    # Triangle element

    # Local coordinates:
        origin: 0-th nodal
        \ksi_0: 0-1 vector
        \ksi_1: 0-2 vector

    # shape_funtion:
        N_0 = 1 - \ksi_0 - \ksi_1 \n
        N_1 = \ksi_0 \n
        N_2 = \ksi_1 \n
    """
    def __init__(self, elems: np.ndarray, nodes: torch.Tensor) -> None:
        super().__init__(elems=elems)

        self.shape_function = [
            torch.tensor([
                [1., -1., -1.],  # N_0
                [0., 1., 0.],  # N_1
                [0., 0., 1.],  # N_2
            ]),
            torch.tensor([
                [[-1., 0., 0.],  # N_0
                [1., 0., 0.],  # N_1
                [0, 0., 0.],],  # N_2
                [[-1., 0., 0.],  # N_0
                 [0, 0., 0.], # N_1
                 [1., 0., 0.]],  # N_2
            ])
        ]

        self._num_gaussian = 1

        self.gaussian_weight = torch.tensor([1/2])
        p0 = torch.tensor([[1/3, 1/3]])
        self._pre_load_gaussian(p0, nodes=nodes)

class triangle_2nd(Surface_base):
    """
    Second order triangle element.

    Local coordinates:
      Use (g, h) with g = ksi, h = eta and L0 = 1 - g - h, L1 = g, L2 = h.

    Shape functions (expressed in the polynomial basis [1, g, h, g*h, g^2, h^2]):
      N0 = 1 - 3*g - 3*h + 2*g**2 + 4*g*h + 2*h**2
      N1 = - g + 2*g**2
      N2 = - h + 2*h**2
      N3 = 4*g - 4*g**2 - 4*g*h
      N4 = 4*g*h
      N5 = 4*h - 4*g*h - 4*h**2

    Their derivatives (symbolically):
      For a function N = a + b*g + c*h + d*g*h + e*g**2 + f*h**2,
      dN/dg = b + 2*e*g + d*h  is represented by [b, 2*e, d, 0, 0, 0],
      dN/dh = c + d*g + 2*f*h  is represented by [c, d, 2*f, 0, 0, 0].
    """
    def __init__(self, elems: np.ndarray, nodes: torch.Tensor) -> None:
        super().__init__(elems=elems)

        # Define shape function coefficients for each node in the basis:
        # [1, g, h, g*h, g^2, h^2]
        self.shape_function = [
            torch.tensor([
                [1.,   -3.,  -3.,   4.,   2.,   2.],  # N0
                [0.,   -1.,   0.,   0.,   2.,   0.],  # N1
                [0.,    0.,  -1.,   0.,   0.,   2.],  # N2
                [0.,    4.,   0.,  -4.,  -4.,   0.],  # N3
                [0.,    0.,   0.,   4.,   0.,   0.],  # N4
                [0.,    0.,   4.,  -4.,   0.,  -4.],  # N5
            ]),
            torch.tensor([
                [  # Derivatives with respect to g
                    [-3.,  4.,  4.,  0., 0., 0.],    # dN0/dg
                    [-1.,  4.,  0.,  0., 0., 0.],    # dN1/dg
                    [ 0.,  0.,  0.,  0., 0., 0.],    # dN2/dg
                    [ 4., -8., -4.,  0., 0., 0.],    # dN3/dg
                    [ 0.,  0.,  4.,  0., 0., 0.],    # dN4/dg (4h)
                    [ 0.,  0., -4.,  0., 0., 0.],    # dN5/dg (-4h)
                ],
                [  # Derivatives with respect to h
                    [-3.,  4.,  4.,  0., 0., 0.],    # dN0/dh
                    [ 0.,  0.,  0.,  0., 0., 0.],    # dN1/dh
                    [-1.,  0.,  4.,  0., 0., 0.],    # dN2/dh
                    [ 0., -4.,  0.,  0., 0., 0.],    # dN3/dh (-4g)
                    [ 0.,  4.,  0.,  0., 0., 0.],    # dN4/dh (4g)
                    [ 4., -4., -8.,  0., 0., 0.],    # dN5/dh
                ]
            ])
        ]

        # Use a 3-point Gauss quadrature for integrating a quadratic polynomial.
        # Standard quadrature points (in (g, h) coordinates) for the triangle:
        self._num_gaussian = 3
        self.gaussian_weight = torch.tensor([1/6, 1/6, 1/6])
        p0 = torch.tensor([
            [1/6, 1/6],
            [2/3, 1/6],
            [1/6, 2/3],
        ])
        self._pre_load_gaussian(p0, nodes=nodes)

class rectangle_1st(Surface_base):
    """
    Bilinear quadrilateral element (first order).
    
    Local coordinates are defined in [-1, 1].
    Shape functions:
      N0 = 0.25*(1-g)*(1-h)
      N1 = 0.25*(1+g)*(1-h)
      N2 = 0.25*(1+g)*(1+h)
      N3 = 0.25*(1-g)*(1+h)
      
    The functions are expressed in the polynomial basis [1, g, h, g*h].
    """
    def __init__(self, elems: np.ndarray, nodes: torch.Tensor) -> None:
        super().__init__(elems=elems)
        self.shape_function = [
            torch.tensor([
                [0.25, -0.25, -0.25,  0.25],   # N0
                [0.25,  0.25, -0.25, -0.25],   # N1
                [0.25,  0.25,  0.25,  0.25],   # N2
                [0.25, -0.25,  0.25, -0.25],   # N3
            ], dtype=torch.float),
            torch.tensor([
                [  # dN/dg: derivative w.r.t g expressed in the same basis
                    [-0.25, 0.0,  0.25, 0.0],   # N0: -0.25 + 0.25*h
                    [ 0.25, 0.0, -0.25, 0.0],   # N1:  0.25 - 0.25*h
                    [ 0.25, 0.0,  0.25, 0.0],   # N2:  0.25 + 0.25*h
                    [-0.25, 0.0, -0.25, 0.0],   # N3: -0.25 - 0.25*h
                ],
                [  # dN/dh: derivative w.r.t h expressed in the same basis
                    [-0.25, 0.25, 0.0,  0.0],   # N0: -0.25 + 0.25*g
                    [-0.25, -0.25,0.0,  0.0],   # N1: -0.25 - 0.25*g
                    [ 0.25, 0.25, 0.0,  0.0],   # N2:  0.25 + 0.25*g
                    [ 0.25, -0.25,0.0,  0.0],   # N3:  0.25 - 0.25*g
                ]
            ], dtype=torch.float)
        ]
        # Use 2x2 Gauss quadrature in the square [-1,1]x[-1,1].
        a = 1 / np.sqrt(3)
        p0 = torch.tensor([
            [-a, -a],
            [ a, -a],
            [ a,  a],
            [-a,  a]
        ], dtype=torch.float)
        self._num_gaussian = 4
        self.gaussian_weight = torch.tensor([1.0, 1.0, 1.0, 1.0], dtype=torch.float)
        self._pre_load_gaussian(p0, nodes=nodes)

class rectangle_2nd(Surface_base):
    def __init__(self, elems: np.ndarray, nodes: torch.Tensor) -> None:
        super().__init__(elems=elems)
        # Coefficients are expressed in the polynomial basis:
        # [1, g, h, g*h, g^2, h^2, g^2*h, g*h^2]
        self.shape_function = [
            torch.tensor([
                [-0.25,  0.0,   0.0,   0.25,  0.25,  0.25, -0.25, -0.25],  # Node (-1,-1)
                [-0.25,  0.0,   0.0,  -0.25,  0.25,  0.25, -0.25,  0.25],  # Node (1,-1)
                [-0.25,  0.0,   0.0,   0.25,  0.25,  0.25,  0.25,  0.25],  # Node (1,1)
                [-0.25,  0.0,   0.0,  -0.25,  0.25,  0.25,  0.25, -0.25],  # Node (-1,1)
                [ 0.5,   0.0,  -0.5,   0.0,  -0.5,   0.0,   0.5,   0.0 ],  # Node (0,-1)
                [ 0.5,   0.5,   0.0,   0.0,   0.0,  -0.5,   0.0,  -0.5 ],  # Node (1,0)
                [ 0.5,   0.0,   0.5,   0.0,  -0.5,   0.0,  -0.5,   0.0 ],  # Node (0,1)
                [ 0.5,  -0.5,   0.0,   0.0,   0.0,  -0.5,   0.0,   0.5 ],  # Node (-1,0)
            ], dtype=torch.float),
            torch.tensor([
                [  # dN/dg computed as: [c1, 2*c4, c3, 2*c6, 0, c7, 0, 0]
                    [0.0,  0.5,  0.25, -0.5, 0.0, -0.25, 0.0, 0.0],
                    [0.0,  0.5, -0.25, -0.5, 0.0,  0.25, 0.0, 0.0],
                    [0.0,  0.5,  0.25,  0.5, 0.0,  0.25, 0.0, 0.0],
                    [0.0,  0.5, -0.25,  0.5, 0.0, -0.25, 0.0, 0.0],
                    [0.0, -1.0,  0.0,   1.0, 0.0,  0.0,  0.0, 0.0],
                    [0.5,  0.0,  0.0,   0.0, 0.0, -0.5,  0.0, 0.0],
                    [0.0, -1.0,  0.0,  -1.0, 0.0,  0.0,  0.0, 0.0],
                    [-0.5, 0.0,  0.0,   0.0, 0.0,  0.5,  0.0, 0.0],
                ],
                [  # dN/dh computed as: [c2, c3, 2*c5, 2*c7, c6, 0, 0, 0]
                    [0.0,  0.25,  0.5, -0.5, -0.25, 0.0, 0.0, 0.0],
                    [0.0, -0.25,  0.5,  0.5, -0.25, 0.0, 0.0, 0.0],
                    [0.0,  0.25,  0.5,  0.5,  0.25, 0.0, 0.0, 0.0],
                    [0.0, -0.25,  0.5, -0.5,  0.25, 0.0, 0.0, 0.0],
                    [-0.5, 0.0,   0.0,  0.0,   0.5,  0.0, 0.0, 0.0],
                    [0.0,  0.0,  -1.0, -1.0,  0.0,  0.0, 0.0, 0.0],
                    [0.5,  0.0,   0.0,  0.0,  -0.5,  0.0, 0.0, 0.0],
                    [0.0,  0.0,  -1.0,  1.0,  0.0,  0.0, 0.0, 0.0],
                ]
            ], dtype=torch.float)
        ]
        # 3-point Gauss–Legendre quadrature in 1D for the interval [-1, 1]
        a = np.sqrt(3/5)
        pts_1d = torch.tensor([-a, 0.0, a], dtype=torch.float)
        wts_1d = torch.tensor([5/9, 8/9, 5/9], dtype=torch.float)
        quad_pts = []
        quad_wts = []
        for i in range(3):
            for j in range(3):
                quad_pts.append([pts_1d[i].item(), pts_1d[j].item()])
                quad_wts.append(wts_1d[i].item() * wts_1d[j].item())
        p0 = torch.tensor(quad_pts, dtype=torch.float)
        self._num_gaussian = p0.shape[0]
        self.gaussian_weight = torch.tensor(quad_wts, dtype=torch.float)
        self._pre_load_gaussian(p0, nodes=nodes)