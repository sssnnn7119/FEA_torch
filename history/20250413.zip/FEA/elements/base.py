
import numpy as np
import torch
from . import materials
from ..obj_base import FEA_Obj_Base

class Element_Base(FEA_Obj_Base):
    _subclasses: dict[str, 'Element_Base'] = {}

    def __init_subclass__(cls):
        """Register subclasses in the class registry for factory method."""
        cls._subclasses[cls.__name__] = cls

    def __init__(self, elems_index: torch.Tensor, elems: torch.Tensor) -> None:

        super().__init__()
        self.shape_function: list[torch.Tensor]
        """
            the shape of shape_function 
        """
        
        self.shape_function_gaussian: list[torch.Tensor]
        """
            the shape of shape_function at each guassian point
        """
        
        self.gaussian_weight: torch.Tensor
        """
        the weight of each guassian point
            [
                g, the num of guassian point
            ]
        """
        self._elems_index = elems_index
        """
            the index of the element
        """
        self._elems = elems
        """
            [elem, N]\n
            the element connectivity 
        """

        self._num_gaussian: int

        self.materials: materials.Materials_Base

        self._indices_matrix: torch.Tensor
        """
            the coo index of the stiffness matricx of structural stress
        """

        self._indices_force: torch.Tensor
        """
            the coo index of the tructural stress
        """

        self._index_matrix_coalesce: torch.Tensor
        """
            the start index of the stiffness matricx of structural stress
        """

        self.density: torch.Tensor
        """
            the density of the element
        """

    def potential_Energy(self, RGC: list[torch.Tensor]):
        pass

    def structural_Force(self, RGC: list[torch.Tensor]):
        pass

    def set_materials(self, materials):
        self.materials = materials

    def set_density(self, density: torch.Tensor |float):
        """
            set the density of the element
        """
        if type(density) == float:
            density = torch.tensor([density], dtype=torch.float32)

        self.density = density
        