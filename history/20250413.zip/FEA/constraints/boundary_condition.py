import numpy as np
import torch
from .base import Constraints_Base

class Boundary_Condition(Constraints_Base):
    """
    Boundary condition base class
    """

    def __init__(self,
                 indexDOF: np.ndarray = np.array([], dtype=int),
                 dispValue: torch.Tensor | float = 0.0) -> None:
        super().__init__()
        self.indexDOF = indexDOF
        if type(dispValue) != torch.Tensor:
            dispValue = dispValue * torch.ones([indexDOF.size])
        self.dispValue = dispValue

    def modify_RGC(self, RGC: list[torch.Tensor]) -> torch.Tensor:
        """
        Apply the boundary condition to the displacement vector
        """
        for i in range(len(self.RGC_list_indexStart) - 1):
            index_now = (self.indexDOF >= self.RGC_list_indexStart[i]) & (
                self.indexDOF < self.RGC_list_indexStart[i + 1])
            RGC[i].view(-1)[
                self.indexDOF[index_now] -
                self.RGC_list_indexStart[i]] = self.dispValue[index_now]
        return RGC

    def set_required_DoFs(
            self, RGC_remain_index: list[np.ndarray]) -> list[np.ndarray]:
        """
        Modify the RGC_remain_index
        """
        for i in range(len(self.RGC_list_indexStart) - 1):
            index_now = (self.indexDOF >= self.RGC_list_indexStart[i]) & (
                self.indexDOF < self.RGC_list_indexStart[i + 1])
            RGC_remain_index[i].reshape(
                -1)[self.indexDOF[index_now] -
                    self.RGC_list_indexStart[i]] = False
        return RGC_remain_index
