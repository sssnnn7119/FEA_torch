import torch
import numpy as np
from .obj_base import FEA_Obj_Base
class ReferencePoint(FEA_Obj_Base):
    """
    ReferencePoints class for handling reference points in a finite element analysis (FEA) framework.
    This class is used to manage the coordinates of reference points, which can be used for various purposes such as boundary conditions, loads, or other constraints in the FEA model.
    """

    def __init__(self, node: list[float] | torch.Tensor = None) -> None:
        """
        Initialize the ReferencePoints class.

        Parameters:
        node (torch.Tensor): A tensor of shape (3) representing the coordinates of the reference point.
        """
        super().__init__()
        if isinstance(node, list):
            node = torch.tensor(node, dtype=torch.float64)
        elif isinstance(node, np.ndarray):
            node = torch.tensor(node.tolist(), dtype=torch.float64)
        self.node = node
        self._RGC_requirements = 6

        