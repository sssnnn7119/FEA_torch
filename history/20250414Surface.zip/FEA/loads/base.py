import numpy as np
import torch
from .. import elements
from ..obj_base import FEA_Obj_Base

class Force_Base(FEA_Obj_Base):

    def __init__(self) -> None:
        super().__init__()
        self._indices_matrix: torch.Tensor = torch.zeros([2, 0],
                                                        dtype=torch.int)
        """
            the coo index of the stiffness matricx of structural stress
        """

        self._indices_force: torch.Tensor
        """
            the coo index of the tructural stress
        """

        self._index_matrix_coalesce: torch.Tensor = torch.zeros([0],
                                                            dtype=torch.int)
        """
            the start index of the stiffness matricx of structural stress
        """

    def get_stiffness(self,
                RGC: list[torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        
        pass

    def get_potential_energy(self, RGC: torch.Tensor) -> torch.Tensor:
        pass
    
    @staticmethod
    def get_F0():
        pass
