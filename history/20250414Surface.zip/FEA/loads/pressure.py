import numpy as np
import torch
from .base import Force_Base
from ..elements.surface import Surface_base

class Pressure(Force_Base):

    def __init__(self, surface_element: list[Surface_base], pressure: float) -> None:
        super().__init__()
        self.surface_element = surface_element
        self.pressure = pressure
        self.init_R: torch.Tensor = None
        """
        the initial position of the nodes
        """

    def get_stiffness(self,
                RGC: list[torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        U = RGC[0].reshape([-1, 3])

        F0_indices, F0_values, matrix_indices, values = self._get_K0_F0(U)

        Rf_values = self.pressure * F0_values

        return F0_indices, Rf_values, matrix_indices, values * self.pressure

    def _get_K0_F0(self, U):
        
        U_now = U + self.init_R

        r = self.surface_element.map_gaussian(U_now, 0)
        rdu = self.surface_element.map_gaussian(U_now, 1)

        return self._indices_force, value.flatten(), self._indices_matrix, values

    def get_potential_energy(self, RGC: list[torch.Tensor]) -> torch.Tensor:

        U_now = RGC[0] + self.init_R

        r = self.surface_element.map_gaussian(U_now, 0)
        rdu = self.surface_element.map_gaussian(U_now, 1)

        epsilon = torch.zeros([3, 3, 3], dtype=torch.float64)
        epsilon[0, 1, 2] = epsilon[1, 2, 0] = epsilon[2, 0, 1] = 1
        epsilon[0, 2, 1] = epsilon[1, 0, 2] = epsilon[2, 1, 0] = -1

        V = torch.einsum('ijk, gei, gej, gek', epsilon, r, rdu[:, :, 0], rdu[:, :, 1])

        return -self.pressure * V

  
    @staticmethod
    def get_F0(nodes, elems, max_RGC_index):
        
        surf_nodes = torch.stack(
            [nodes[elems[:, i]]
             for i in [0, 1, 2]],
            dim=0)

        value = (-1 / 6) * torch.cat([
            torch.cross(surf_nodes[1], surf_nodes[2], dim=1),
            torch.cross(surf_nodes[2], surf_nodes[0], dim=1),
            torch.cross(surf_nodes[0], surf_nodes[1], dim=1)
        ],
                                     dim=0)
        
        indices_force = elems.transpose(
            0, 1).unsqueeze(-1).repeat([1, 1, 3]).reshape([-1, 3])
        indices_force = indices_force * 3
        indices_force[:, 1] += 1
        indices_force[:, 2] += 2
        indices_force = indices_force.flatten()

        F0 = torch.zeros([max_RGC_index]).scatter_add(0, indices_force,
                                         value.flatten())
        
        return F0
