

import torch
from . import constraints, elements, loads
from .elements import materials
from .FEA_INP import FEA_INP
from .Main import FEA_Main
from .reference_points import ReferencePoint

def from_inp(inp: FEA_INP) -> FEA_Main:
    """
    Load a FEA model from an INP file.

    Args:
        file_path (str): Path to the INP file.

    Returns:
        FEA_Main: An instance of the FEA_Main class.
    """

    part_name = list(inp.part.keys())[0]

    fe = FEA_Main(inp.part[part_name].nodes[:, 1:])
    elems = inp.part[part_name].elems
    
    for key in list(elems.keys()):

        materials_type = inp.part[part_name].elems_material[elems[key][:, 0], 2].type(torch.int).unique()
        for mat_type in materials_type:
            index_now = torch.where(inp.part[part_name].elems_material[elems[key][:, 0], 2].type(torch.int) == mat_type)

            materials_now = materials.initialize_materials(
                materials_type=mat_type.item(),
                materials_params=inp.part[part_name].elems_material[elems[key][:, 0]][index_now][:, 3:]
            )

            elems_now = elements.initialize_element(
                        element_type=key,
                        elems_index=torch.from_numpy(elems[key][:, 0]),
                        elems=torch.from_numpy(elems[key][:, 1:]),
                        nodes=inp.part[part_name].nodes[:, 1:],
                        )
            
            elems_now.set_materials(materials_now)
            elems_now.set_density(inp.part[part_name].elems_material[elems[key][:, 0]][index_now][:, 1])
            
            fe.add_element(elems_now)

    return fe